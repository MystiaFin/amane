use crate::{Color, Fill, Radius, Rectangle, Size};

pub struct NeedsHeight {
    pub(crate) width: Size,
}

impl NeedsHeight {
    pub fn height(self, height: impl Into<Size>) -> Rectangle {
        Rectangle {
            width: self.width,
            height: height.into(),
            radius: Radius::Fixed(0.0),
            fill: Fill::Color(Color::TRANSPARENT),
            border_thickness: 0.0,
            border_color: Color::TRANSPARENT,
            blur: 0.0,
            opacity: 1.0,
            child: None,
        }
    }
}
